def policy(resource):
    return not resource["PubliclyAccessible"]
