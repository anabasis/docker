require([
    'underscore',
	'jquery',
	'splunkjs/mvc',
    "splunkjs/mvc/searchmanager",
    "splunkjs/mvc/tableview",
    'splunkjs/mvc/simplexml/ready!'
], function(_, $, mvc, SearchManager, TableView) {

    var f5_host = $('[id="hidden_f5_host"]');
    var f5_username = $('[id="hidden_f5_username"]');
    var f5_password = $('[id="hidden_f5_password"]');
    var waf_policy_name = $('[id="hidden_waf_policy_name"]');
        
    var data_table = mvc.Components.get('data_table');
    var input_ip = $('[id="input_ip"]');
    var input_netmask = $('[id="input_netmask"]');
    var input_blockrequest = $('[id="input_blockrequest"]'); // 고정값
    var input_description = $('[id="input_description"]');
    var returnMessage = $('[id="returnMessage"]');
    var callApiBtn = $('#callApiBtn')

    data_table.on('click', function(e) {
        e.preventDefault();
        returnMessage.text(''); // 초기화
        input_ip.val(e.data['row.ip']);
        input_netmask.val(e.data['row.netmask']);
        input_blockrequest.val('always');
        input_description.val(e.data['row.description']);
    });

    // 등록
    callApiBtn.on('click', function() {
        callApiBtn.attr('disabled', true);
        returnMessage.text('Call API 등록 버튼이 클릭되었습니다.'); 
        console.log("Call API 등록 버튼이 클릭되었습니다.");
        f5WafEntry(); // f5WafEntry 함수
        returnMessage.text('처리중............'); 
    });

    function f5WafEntry(){
        console.log("f5WafEntry 함수가 호출되었습니다.");
        var searchQuery = `| f5wafapi f5_host="${f5_host.val()}", f5_username="${f5_username.val()}" f5_password="${f5_password.val()}" waf_policy_name="${waf_policy_name.val()}" ip="${input_ip.val()}" netmask="${input_netmask.val()}" blockrequest="${input_blockrequest.val()}" description="${input_description.val()}"`;
        console.log("Search Query: " + searchQuery);

        var mySearch = mvc.Components.get("f5waf_api_search");
        if (!mySearch) {
            mySearch = new SearchManager({
                id: "f5waf_api_search",
                search: searchQuery
            });
        }else{
            mySearch.set({ search: searchQuery });
            mySearch.startSearch(); 
            console.log("SearchManager가 이미 존재하여 업데이트되었습니다.");   
        }

        // search:done 이벤트 등록
        mySearch.on("search:done", function(properties) {
            console.log("Search is done.");
            callApiBtn.attr('disabled', false);
        }).on("search:error", function(error) {
            console.error("Search error:", error);
            callApiBtn.attr('disabled', false);
            returnMessage.text('API 호출 중 오류가 발생했습니다.');
        });

        // 결과 모델 지정 (내장됨)
        var resultsModel = mySearch.data("results");

        // 데이터 로드 완료 시
        resultsModel.on("data", function() {
            var fields = resultsModel.data().fields;
            var rows = resultsModel.data().rows;
            var status = "";
            var message = "";

            console.log("✅ Fields:", fields);
            console.log("✅ Rows:", rows);

            // JSON 변환
            var json = rows.map(row => {
                var obj = {};
                fields.forEach((f, i) => obj[f] = row[i]);
                return obj;
            });
            console.log("📦 JSON 결과:", json);
            console.log("📦 JSON 첫 번째 결과 상태:", json[0]['status']); // json[0].status

            if(json[0]['status'] == "success") {
                status = "성공";
            } else {
                status = "실패";
            } 
            // 결과 출력
            //alert("API 호출 결과: " + status);
            //alert("메시지: " + json[0]['message']);
            returnMessage.text(json[0]['message']);
            callApiBtn.attr('disabled', false);
        });
    };
});
