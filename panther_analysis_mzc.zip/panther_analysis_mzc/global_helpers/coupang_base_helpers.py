from datetime import datetime
from panther_core import PantherEvent

def reformat_timestamp(timestamp: str) -> str:
    timestamp = timestamp[:26]
    try:
        current_dt = datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%S.%f")
    except ValueError:
        try:
            current_dt = datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S.%f")
        except ValueError as e:
            raise ValueError("Invalid timestamp format") from e
    
    return current_dt.strftime("%Y/%m/%d %H:%M:%S.%3N")


def coupang_context(func) -> dict:
    rule_params = func.__globals__
    def wrapper(event: PantherEvent) -> dict:
        # Try to ascertain the following values from the rule code
        hl_code = rule_params.get("HL_CODE", "UNKNOWN CODE")
        # drilldown = rule_params.get("DRILLDOWN", "UNKNOWN DRILLDOWN NAME")
        # drilldown_dashboards = rule_params.get("DRILLDOWN_DASHBOARDS", [])
        ocsf_category = rule_params.get("OCSF_CATEGORY", "")
        ocsf_class = rule_params.get("OCSF_CLASS", "")
        ocsf_class_id = rule_params.get("OCSF_CLASS_ID", "")

        security_domain = rule_params.get("SECURITY_DOMAIN", "UNKNOWN SECURITY DOMAIN")
        description = rule_params.get("DESCRIPTION", "")
        rule_title = rule_params.get("RULE_TITLE", "")
        rule_name = rule_params.get("RULE_NAME", "")
        severity = rule_params.get("SEVERITY", "")

        # NOTE: Several of these fields aren't available in the alert_context, but can instead be referenced in the response of the list-alerts API endpoint.
        base_context = {
            "_time": datetime.now().strftime("%Y/%m/%d %H:%M:%S.%3N"),
            "event_time": reformat_timestamp(event["p_event_time"]),
            "indextime": reformat_timestamp(event["p_parse_time"]),
            # "drilldown_earliest": None, # use firstEventOccuretAt
            # "drilldown_latest": None, # use lastEventOccuredAt
            # "drilldown_search": "",
            # "drilldown_name": drilldown,
            # "drilldown_dashboards": drilldown_dashboards,
            "HLcode": hl_code,
            "ocsf_category": ocsf_category,
            "ocsf_class": ocsf_class,
            "ocsf_class_id": ocsf_class_id,
            "security_domain": security_domain,
            "search_list": None,
            "count": 1, # use eventCount
            "rule_description": description, # not available in alert_context or API, but runbook is
            "rule_name": rule_name, # use rule.id
            "rule_title": rule_title, # use title
            "severity": severity, # use severity
        }
        return base_context | func(event)
    
    return wrapper
