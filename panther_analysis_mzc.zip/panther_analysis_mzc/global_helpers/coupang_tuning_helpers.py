from datetime import datetime, timedelta

from panther_detection_helpers.caching import get_counter, increment_counter

EXPIRATION = 24 * 3600


def bin_key(timestamp: str, binsize: int, key: str, offset: int = 0):
    timestamp = datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%S.%fZ")
    epoch_time = timestamp.timestamp()
    binsize *= 60 # Convert from minutes to seconds
    bin_time = (epoch_time // binsize - offset) * binsize
    rounded_tstamp = datetime.fromtimestamp(bin_time).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    return f"{rounded_tstamp}:{key}"


def bin_increment_counter(timestamp: str, binsize: int, key: str, val: int=1, epoch_seconds: int=EXPIRATION):
    bin_key = bin_key(timestamp, binsize, key)
    increment_counter(bin_key, val, epoch_seconds)


def bin_get_counter(timestamp: str, binsize: int, key: str, span: int = 1):
    total = 0
    for offset in range(span):
        bin_key = bin_key(timestamp, binsize, key, offset)
        total += get_counter(bin_key)
    return total