#!/bin/bash

# 사용법 안내
if [ -z "$1" ]; then
  echo "Usage: $0 <RuleID>"
  exit 1
fi

RULE_ID="$1"

# Panther Rule 테스트 실행
panther_analysis_tool test \
  --path ./rules/megazone_rules/ \
  --filter RuleID="$RULE_ID" 
