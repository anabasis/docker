import inspect

from coupang_tuning_helpers import bin_key
from panther_detection_helpers.caching import (add_to_string_set,
                                               increment_counter)


def get_rule_id():
    """Returns the rule ID of the rule currently being executed."""
    frame = inspect.currentframe()
    while frame.f_code.co_name != "rule":
        frame = frame.f_back
    return frame.f_locals.get("__module__").__name__


def cache_login(event, actor) -> int:
    """Caches a login event for the given target and actor, and returns the new number of logins for the current period."""
    key = bin_key(event["p_event_time"], 1, f"{get_rule_id()}:{event['p_log_type']}:{actor}:all")
    return increment_counter(key, 1)


def cache_failure(event, actor) -> int:
    """Caches a failure event for the given target and actor, and returns the new number of failures for the current period."""
    key = bin_key(event["p_event_time"], 1, f"{get_rule_id()}:{event['p_log_type']}:{actor}:failed")
    return increment_counter(key, 1)


def cache_target(event, actor, target) -> set[str]:
    """Caches a target for the given actor."""
    key = bin_key(event["p_event_time"], 1, f"{get_rule_id()}:{event['p_log_type']}:{target}:{actor}:targets")
    return add_to_string_set(key, target, 3600)


def check_above_failure_rate(n_all, n_failed, threshold: float = 0.3) -> bool:
    """Checks if the failure rate is above the given threshold."""
    return n_all > 10 and n_failed / n_all > threshold


def is_password_guessing(event, actor, target, is_failed, rate_threshold, target_threshold) -> dict:
    """Checks if the event is a password guessing event."""
    # Log a successful login
    n_all = cache_login(event, actor)
    if not is_failed:
        return {
            "result": False,
            "targets": set(),
            "rate": 0,
        }
    # Log a failed login
    n_failed = cache_failure(event, actor)

    failure_rate = n_failed / n_all
    targets = cache_target(event, actor, target)
    return {
        "result": check_above_failure_rate(n_all, n_failed, rate_threshold),
        "targets": targets,
        "rate": failure_rate,
    }