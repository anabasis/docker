def rule(_):
    return True
