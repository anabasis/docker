require([
    'underscore',
	'jquery',
	'splunkjs/mvc',
    "splunkjs/mvc/searchmanager",
    "splunkjs/mvc/tableview",
    'splunkjs/mvc/simplexml/ready!'
], function(_, $, mvc, SearchManager, TableView) {
    
    var data_table = mvc.Components.get('data_table');
    var returnMessage = $('[id="returnMessage"]');
    var callApiBtn = $('#callApiBtn')

    var mainSearch = mvc.Components.get("main_table");
    var result = {}

    mainSearch.on("search:done", function(properties) {
        console.log("Search is done.");
    }).on("search:error", function(error) {
        console.error("Search error:", error);
        returnMessage.text('API 호출 중 오류가 발생했습니다.');
    }).on("search:start", function(properties){
        console.log("Search is Start.");
        result = {}
    })

    // 결과 모델 지정 (내장됨)
    var mainTableModel = mainSearch.data("results");
    mainTableModel.on("data", function() {
        var fields = mainTableModel.data().fields;
        var rows = mainTableModel.data().rows;

        console.log("✅ Fields:", fields);
        console.log("✅ Rows:", rows);
        
        // JSON 변환
        var json = rows.map(row => {
            var obj = {};
            fields.forEach((f, i) => obj[f] = row[i]);
            return obj;
        });
        console.log("📦 JSON 결과:", json);
        result = json
        returnMessage.text('');
    });


    // 등록
    callApiBtn.on('click', function() {
        console.log("Data Result --------->" + Object.keys(result).length);
        if (Object.keys(result).length > 0) {
            callApiBtn.attr('disabled', true);
            returnMessage.text('Call API 등록 버튼이 클릭되었습니다.'); 
            console.log("Call API 등록 버튼이 클릭되었습니다.");
            f5WafEntry(); // f5WafEntry 함수
            returnMessage.text('처리중............'); 
        } else {
            returnMessage.text('호출할 데이터가 없습니다. '); 
        }
    });

    function f5WafEntry(){
        var cnt = 0

        var searchQuery = "";
        result.forEach((item, index) => {
            
            policy = `${item.policy_list}`
            var policy_list = policy.split("@#").map(policy => {
                var parts = policy.split("&|");
                return {
                    policy_name: parts[0],
                    id: parts[1],
                    f5_host: parts[2],
                    description: parts[3]
                };
            });
            console.log(policy_list);

            if (index == 0) {
                for (let i = 0; i < policy_list.length; i++) {
                    if (i == 0) {
                        searchQuery = `| f5wafapi f5_host="${policy_list[i].f5_host}", f5_username="${policy_list[i].id}" waf_policy_name="${policy_list[i].policy_name}" ip="${item.ip}" netmask="${item.netmask}" blockrequest="${item.blockrequest}" description="${item.description}"`;
                    } else {
                        searchQuery = searchQuery + `| append [ | f5wafapi f5_host="${policy_list[i].f5_host}", f5_username="${policy_list[i].id}" waf_policy_name="${policy_list[i].policy_name}" ip="${item.ip}" netmask="${item.netmask}" blockrequest="${item.blockrequest}" description="${item.description}" ]`;      
                    }
                }
            } else {
                for (let i = 0; i < policy_list.length; i++) {
                    searchQuery = searchQuery + `| append [ | f5wafapi f5_host="${policy_list[i].f5_host}", f5_username="${policy_list[i].id}" waf_policy_name="${policy_list[i].policy_name}" ip="${item.ip}" netmask="${item.netmask}" blockrequest="${item.blockrequest}" description="${item.description}" ]`;      
                }
            }
        });
        searchQuery = searchQuery + `| stats values(message) as message values(status) as status by ip netmask blockrequest description`
        console.log("Search Query: " + searchQuery);

        var mySearch = mvc.Components.get(`f5waf_api_search`);
        if (!mySearch) {
            mySearch = new SearchManager({
                id: "f5waf_api_search",
                search: searchQuery
            });
        }else{
            mySearch.set({ search: searchQuery });
            mySearch.startSearch(); 
        }
        mySearch.on("search:done", function(properties) {
            console.log(`Search is done. f5waf_api_search`);
        }).on("search:error", function(error) {
            console.error("Search error:", error);
        });

        // 결과 모델 지정 (내장됨)
        var resultsModel = mySearch.data("results");
        // 데이터 로드 완료 시
        resultsModel.on("data", function() {
            var fields = resultsModel.data().fields;
            var rows = resultsModel.data().rows;
            var status = "";
            // var message = "";
            // console.log("✅ Fields:", fields);
            // console.log("✅ Rows:", rows);
            // JSON 변환
            var json = rows.map(row => {
                var obj = {};
                fields.forEach((f, i) => obj[f] = row[i]);
                return obj;
            });
            console.log("📦 JSON RESULT 결과:", json);

            // Status 업데이트
            var lookupQuery = "| inputlookup f5_waf_list.csv ";
            for (let i = 0; i < json.length; i++) {
               console.log(json[i].ip, json[i].netmask);
               lookupQuery = lookupQuery + `| eval status = if(ip=="${json[i].ip}" and netmask=="${json[i].netmask}","${json[i].status}",status)`
               lookupQuery = lookupQuery + `| eval description = if(ip=="${json[i].ip}" and netmask=="${json[i].netmask}","${json[i].message}",description)`
            }
            lookupQuery = lookupQuery + `| outputlookup f5_waf_list.csv `
            console.log("Lookup Query: " + lookupQuery);
            
            var lookupSearch = mvc.Components.get(`lookup_update_query`);
            if (!lookupSearch) {
                lookupSearch = new SearchManager({
                    id: "lookup_update_query",
                    search: lookupQuery
                });
            }else{
                lookupSearch.set({ search: lookupQuery });
                lookupSearch.startSearch(); 
            }
            
            // search:done 이벤트 등록
            lookupSearch.on("search:done", function(properties) {
                console.log(`lookup Search Done`);
                callApiBtn.attr('disabled', false);
                mainSearch.startSearch(); 
                returnMessage.text("처리 완료");
            }).on("search:error", function(error) {
                console.error("Search error:", error);
                callApiBtn.attr('disabled', false);
                mainSearch.startSearch(); 
                returnMessage.text(error);
            });
        });
        console.log("f5WafEntry 함수가 호출되었습니다.");
    }
});
