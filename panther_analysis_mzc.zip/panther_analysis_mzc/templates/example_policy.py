def policy(resource):
    return resource["Thing"]
