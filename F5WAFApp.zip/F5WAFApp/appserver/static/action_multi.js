require([
    'underscore',
	'jquery',
	'splunkjs/mvc',
    "splunkjs/mvc/searchmanager",
    "splunkjs/mvc/tableview",
    'splunkjs/mvc/simplexml/ready!'
], function(_, $, mvc, SearchManager, TableView) {
    
    var data_table = mvc.Components.get('data_table');
    var returnMessage = $('[id="returnMessage"]');
    var callApiBtn = $('#callApiBtn')

    var mainSearch = mvc.Components.get("main_table");

    mainSearch.on("search:done", function(properties) {
        console.log("Search is done.");
    }).on("search:error", function(error) {
        console.error("Search error:", error);
        returnMessage.text('API 호출 중 오류가 발생했습니다.');
    });
    // 결과 모델 지정 (내장됨)
    var result = {}
    var mainTableModel = mainSearch.data("results");
    mainTableModel.on("data", function() {
        var fields = mainTableModel.data().fields;
        var rows = mainTableModel.data().rows;

        console.log("✅ Fields:", fields);
        console.log("✅ Rows:", rows);
        // JSON 변환
        var json = rows.map(row => {
            var obj = {};
            fields.forEach((f, i) => obj[f] = row[i]);
            return obj;
        });
        console.log("📦 JSON 결과:", json);
        result = json
    });

    // 등록
    callApiBtn.on('click', function() {
        callApiBtn.attr('disabled', true);
        returnMessage.text('Call API 등록 버튼이 클릭되었습니다.'); 
        console.log("Call API 등록 버튼이 클릭되었습니다.");
        f5WafEntry(); // f5WafEntry 함수
        returnMessage.text('처리중............'); 
    });

    function f5WafEntry(){
        var cnt = 0

        var searchQuery = "";
        result.forEach((item, index) => {
            // console.log(`🔹 정책 ${index + 1}`);
            // console.log(`- 이름: ${item.policy_name}`);
            // console.log(`- F5 호스트: ${item.f5_host}`);
            // console.log(`- IP: ${item.ip}`);
            // console.log(`- 설명: ${item.description}`);
            // console.log('-------------------------');

            if (index == 0) {
                searchQuery = `| f5wafapi f5_host="${item.f5_host}", f5_username="${item.id}" f5_password="${item.pwd}" waf_policy_name="${item.policy_name}" ip="${item.ip}" netmask="${item.netmask}" blockrequest="${item.blockrequest}" description="${item.description}"`;
            } else {
                searchQuery = searchQuery + `| append [ | f5wafapi f5_host="${item.f5_host}", f5_username="${item.id}" f5_password="${item.pwd}" waf_policy_name="${item.policy_name}" ip="${item.ip}" netmask="${item.netmask}" blockrequest="${item.blockrequest}" description="${item.description}" ]`;
            }
        });
        console.log("Search Query: " + searchQuery);

        var mySearch = mvc.Components.get(`f5waf_api_search`);
        if (!mySearch) {
            mySearch = new SearchManager({
                id: "f5waf_api_search",
                search: searchQuery
            });
        }else{
            mySearch.set({ search: searchQuery });
            mySearch.startSearch(); 
        }
        mySearch.on("search:done", function(properties) {
            console.log(`Search is done. f5waf_api_search`);
        }).on("search:error", function(error) {
            console.error("Search error:", error);
        });

        // 결과 모델 지정 (내장됨)
        var resultsModel = mySearch.data("results");
        // 데이터 로드 완료 시
        resultsModel.on("data", function() {
            var fields = resultsModel.data().fields;
            var rows = resultsModel.data().rows;
            var status = "";
            // var message = "";
            // console.log("✅ Fields:", fields);
            // console.log("✅ Rows:", rows);
            // JSON 변환
            var json = rows.map(row => {
                var obj = {};
                fields.forEach((f, i) => obj[f] = row[i]);
                return obj;
            });
            console.log("📦 JSON RESULT 결과:", json);

            // Status 업데이트
            var lookupQuery = "| inputlookup f5_waf_list.csv ";
            for (let i = 0; i < json.length; i++) {
               console.log(json[i].ip, json[i].netmask);
               lookupQuery = lookupQuery + `| eval status = if(ip=="${json[i].ip}" and netmask=="${json[i].netmask}","${json[i].status}",status)`
            }
            lookupQuery = lookupQuery + `| outputlookup f5_waf_list.csv `
            console.log("Lookup Query: " + lookupQuery);
            
            var lookupSearch = mvc.Components.get(`lookup_update_query`);
            if (!lookupSearch) {
                lookupSearch = new SearchManager({
                    id: "lookup_update_query",
                    search: lookupQuery
                });
            }else{
                lookupSearch.set({ search: lookupQuery });
                lookupSearch.startSearch(); 
            }
            
            // search:done 이벤트 등록
            lookupSearch.on("search:done", function(properties) {
                console.log(`lookup Search Done`);
                returnMessage.text("처리 완료");
                callApiBtn.attr('disabled', false);
            }).on("search:error", function(error) {
                console.error("Search error:", error);
                returnMessage.text(error);
                callApiBtn.attr('disabled', false);
            });
        });
        console.log("f5WafEntry 함수가 호출되었습니다.");
    }
});
